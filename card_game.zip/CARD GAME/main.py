﻿from tkinter import *
import json


class Game:
    def __init__(self):
        self.player1 = Player()
        self.player2 = Player()
        self.turn_num = 0
        self.window = Tk()
        self.window.title("Card Game")
        self.width = 900
        self.height = 450
        self.canv = Canvas(self.window, width = self.width, height =self.height, bg ='Grey')
        self.canv.pack(padx =0, pady =0)
        self.player1.test()
        self.player1.hand[0].draw(self.canv, 0,0)
        self.canv.bind("<Button-1>", self.click_handler)

    def start(self):
        self.window.mainloop()

    def click_handler(self,e):
        print((e.x,e.y))
        print(self.player1.hand[0].is_clicked((e.x,e.y)))



class Player:
    def __init__(self):
        self.deck = []
        self.base_deck = []
        self.health = 15
        self.mana_max = 1
        self.hand = []
    def draw_card(self):
        return
    def test(self):
        self.hand.append(Card({"image": "./patchouli.gif","attack": 8, "health": 7, "mana":7}))




class Card:
    def __init__(self, card):
        self.image = PhotoImage(file=card["image"])
        self.attack = card["attack"]
        self.health = card["health"]
        self.cost = card["mana"]
        self.coords = (-1000,-1000)

    def draw(self,canv,x,y):
        self.coords = (x,y)
        canv.create_image(x,y, anchor=NW, image=self.image)

    def is_clicked(self,coords):
        print(self.image.width())
        if self.coords[0] < coords[0] < self.coords[0] + self.image.width():
            if self.coords[1] < coords[1] < self.coords[1] + self.image.height():
                return True
        return False




game = Game()
game.start()

